Cascaded_LSTM_m4: the cascaded_LSTM scheme with 4 preidictions.
Cascaded_LSTM_m9: the cascaded_LSTM scheme with 9 preidictions.